# The Dark Room of DCX — test selection patch (PDF pages 112–136)

This is a small companion patch, not a replacement for `DCX-DarkRoom-Expansion-060-102.zip`.

## Included test details
- `DCX-SAMPLE-001_p128_choker-detail.avif`: isolated crop of a dark choker and circular pendant from PDF page 128. This is an alternate accessory reference, not a replacement for DCX’s permanent left-wrist bracelet.
- `DCX-SAMPLE-002_p130_red-tiled-water-setting.avif`: environment-only crop from PDF page 130 showing a red wall, tile band and water; no person is included in this crop.

Both assets are AVIF (AV1, CRF 18, YUV 4:4:4) and keep the crop's native pixel dimensions. They are intended for review as references, not yet added to the public gallery manifest.

## Exclusions
The rest of pages 112–136 were not copied into this patch because they either contain explicit/intimate framing, repeat accessory/mesh/sock/pose families already in the existing archive, or do not offer a distinct suitable public test reference. The user's statement that the set depicts adults is recorded as context, but it does not make explicit imagery appropriate for an ungated public gallery.
