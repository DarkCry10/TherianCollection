# The Dark Room of DCX — análisis de ampliación 060–102

## Alcance y decisiones de archivo

- El PDF `3.0 DCX.pdf` contiene 136 páginas. El bloque inicial contiene las imágenes que coinciden con las 56 fichas ya documentadas; se reconocieron como material previamente descrito y no se vuelven a analizar aquí.
- En las páginas 51–111 se localizaron 78 ubicaciones de imagen que, tras deduplicar por hash binario, dan **43 imágenes nuevas y únicas** (DCX-REF-060 a DCX-REF-102). Las repeticiones se conservan en `sourcePages`.
- No se identificó un original alternativo de mayor resolución para las 56 referencias existentes. Por ello, no se sustituyen ni se reescalan.
- Las 43 incorporaciones se codificaron como AVIF real (AV1, CRF 18, YUV 4:4:4), manteniendo sus dimensiones nativas. El AVIF preserva el tamaño en píxeles disponible en el PDF; no inventa detalle. Algunas fuentes son pequeñas (el mínimo es 324×639 px).
- Las referencias 090–092 recuperan claramente la máscara Kitsune del diseño central. Las 093–094 usan una máscara alternativa tipo Guy Fawkes y quedan etiquetadas como estudio de utilería/máscara, no como canon. La mayoría de las demás son estudios de pose o vestuario sin máscara.
- Las páginas 112–136 se excluyen por contener material sexual explícito. No se describen ni se distribuyen en el paquete público.

## Lectura general del nuevo bloque

El bloque añade tres familias especialmente útiles: (1) una secuencia de vestuario negro con tirantes y construcción tipo delantal en un entorno de cocina (REF-074–080 y REF-095–096); (2) estudios de pose, accesorios y prendas de pierna/ropa interior que amplían el archivo de siluetas y referencias históricas (REF-060–073 y REF-081–087); y (3) tres referencias enmascaradas que permiten contrastar la máscara Kitsune canónica bajo luz fría y verde (REF-090–092), más una pareja de referencias de máscara alternativa (REF-093–094). Estas categorías evitan convertir cada foto de archivo en una nueva apariencia oficial.

## Fichas individuales

### DCX-REF-060 · página(s) 51, 79

**Familia:** Estudio de accesorio / media  
**Dimensiones de fuente:** 639 × 639 px  
**Descripción:** Recorte cuadrado muy cercano de una pierna flexionada con calcetín alto oscuro y detalle multicolor. El encuadre elimina casi todo el contexto y convierte la media en el centro visual.  
**Análisis / uso:** Documenta un accesorio de la etapa temprana: bloque oscuro, bandas o acentos arcoíris y contraste con fondo claro. Es útil para recuperar detalles de estilismo, no como definición del vestuario SXW consolidado.  
**Observación de archivo:** El color multicolor aparece como acento pequeño, no como una paleta ambiental. Conviene mantenerlo como detalle histórico separado del cinturón azul AMX.

### DCX-REF-061 · página(s) 52, 81

**Familia:** Estudio de pose / vista posterior  
**Dimensiones de fuente:** 359 × 639 px  
**Descripción:** Vista de tres cuartos desde atrás; la figura gira la cabeza y lleva una mano hacia la cabeza. Se aprecian ropa interior clara y calcetines largos con acentos multicolor.  
**Análisis / uso:** Registra la relación entre giro de hombros, posición del brazo y continuidad de las prendas desde la espalda. Complementa las tomas frontales del archivo sin introducir una nueva apariencia canónica.  
**Observación de archivo:** Los accesorios de pierna vuelven a funcionar como acento de vestuario y aportan continuidad con la referencia 060.

### DCX-REF-062 · página(s) 53, 82

**Familia:** Estudio de pose / dormitorio  
**Dimensiones de fuente:** 460 × 639 px  
**Descripción:** Composición centrada desde atrás sobre una cama, con ropa interior oscura y pared neutra. El fondo sencillo deja que la silueta y la postura sean lo dominante.  
**Análisis / uso:** Referencia de postura posterior y distribución del peso sobre una superficie blanda. La ausencia de máscara y de vestuario identificador la sitúa en el archivo de estudios, no en el canon visual principal.  
**Observación de archivo:** El entorno doméstico funciona como fondo neutro, a diferencia de los escenarios de iluminación FireIce, Blood Cherry y Grass Bass.

### DCX-REF-063 · página(s) 54, 83

**Familia:** Estudio de pose / luz roja  
**Dimensiones de fuente:** 462 × 639 px  
**Descripción:** Pose posterior en tres cuartos, arrodillada o apoyada, ante una pared roja. Se distingue un brazalete oscuro en la muñeca y una prenda inferior negra.  
**Análisis / uso:** La imagen conserva una lectura clara de la línea del hombro, el giro del torso y el apoyo del brazo. El brazalete puede servir como referencia aislada del accesorio permanente, aunque la imagen no muestra la máscara.  
**Observación de archivo:** El rojo aquí es luz/ambiente de habitación y no basta para clasificarla como Blood Cherry canónico.

### DCX-REF-064 · página(s) 55, 84

**Familia:** Estudio de silueta / recorte lateral  
**Dimensiones de fuente:** 531 × 639 px  
**Descripción:** Encuadre cerrado de perfil posterior y cintura ante una pared rojiza apagada; el interés principal es la curva de la silueta y la transición de la prenda oscura.  
**Análisis / uso:** Puede usarse para estudiar recortes y proporciones desde un ángulo lateral, sin atribuirle una variante completa de vestuario.  
**Observación de archivo:** Su valor es compositivo y de silueta; no presenta los elementos identitarios necesarios para una ficha canónica.

### DCX-REF-065 · página(s) 56, 86

**Familia:** Estudio corporal / pose frontal sentada  
**Dimensiones de fuente:** 643 × 639 px  
**Descripción:** Figura sentada de frente, con la cabeza fuera del encuadre, prenda inferior clara y un collar o accesorio visible sobre el torso. La pared roja y la ropa de cama aportan un ambiente doméstico cálido.  
**Análisis / uso:** Registra la postura sentada frontal y la forma en que los accesorios caen sobre el torso. Al estar el rostro fuera de cuadro, no permite validar la identidad Kitsune.  
**Observación de archivo:** La iluminación roja debe leerse como estudio de ambiente, no como una aplicación estricta de Blood Cherry.

### DCX-REF-066 · página(s) 57, 87

**Familia:** Estudio de pose / diagonal  
**Dimensiones de fuente:** 470 × 639 px  
**Descripción:** Toma diagonal desde el costado y la espalda sobre una cama; la ropa interior oscura y el diseño de la ropa de cama dividen el cuadro en franjas.  
**Análisis / uso:** Aporta una variante de ángulo bajo y pose reclinada para futuras composiciones, con énfasis en la perspectiva y la relación figura-superficie.  
**Observación de archivo:** La diagonal y el patrón textil son más importantes que la identidad del vestuario.

### DCX-REF-067 · página(s) 58, 88

**Familia:** Estudio de vestuario oscuro / dormitorio  
**Dimensiones de fuente:** 852 × 639 px  
**Descripción:** Vista lateral de una figura apoyada junto a una cama oscura, con prenda inferior negra y tirantes o bandas que dibujan líneas sobre el cuerpo.  
**Análisis / uso:** Referencia de cómo los elementos oscuros se separan del cabecero y de la ropa de cama. Puede inspirar una variante de estilismo, pero no debe etiquetarse como Gloom Grass completo porque no reúne chaqueta biker, fishnet y cadena.  
**Observación de archivo:** La oscuridad del atuendo no equivale por sí sola al código industrial verde de Gloom Grass.

### DCX-REF-068 · página(s) 59, 89

**Familia:** Estudio de pose / calcetines altos  
**Dimensiones de fuente:** 713 × 639 px  
**Descripción:** Pose frontal sentada con ropa interior oscura y calcetines altos de bandas arcoíris. La toma introduce una lectura más completa del conjunto y del largo de las medias.  
**Análisis / uso:** Permite estudiar la proporción de las medias respecto de la pierna y la silueta sentada. Es una referencia de estilismo histórico, no un diseño final de SXW.  
**Observación de archivo:** Las bandas multicolor conectan con el lenguaje temprano de CK/arcoíris descrito en el manual del personaje.

### DCX-REF-069 · página(s) 59, 89

**Familia:** Estudio de pose / plano amplio  
**Dimensiones de fuente:** 852 × 639 px  
**Descripción:** Versión más abierta de la pose frontal sentada, con mayor contexto de la postura y las medias altas multicolor.  
**Análisis / uso:** Amplía la referencia 068 al permitir leer mejor la pose completa y la relación entre prendas y encuadre. Se conserva como variante distinta porque el campo visual y la composición cambian de forma sustancial.  
**Observación de archivo:** Conviene agruparla con la 068 como familia de pose, no eliminarla como duplicado.

### DCX-REF-070 · página(s) 59, 89

**Familia:** Estudio de pose / recorte posterior  
**Dimensiones de fuente:** 479 × 639 px  
**Descripción:** Plano bajo desde atrás y de lado, con una mano apoyada en la cadera y medias altas oscuras con franjas de color.  
**Análisis / uso:** Aporta un encuadre muy cerrado de gesto y accesorio: la mano define el eje compositivo y la media ancla el extremo inferior.  
**Observación de archivo:** Útil como referencia secundaria de gesto; no representa un look completo por sí sola.

### DCX-REF-071 · página(s) 60, 90

**Familia:** Estudio de pose posterior / cama  
**Dimensiones de fuente:** 479 × 639 px  
**Descripción:** Vista posterior inclinada hacia delante sobre la cama, con ropa interior negra y calcetines altos oscuros.  
**Análisis / uso:** Registra una postura de apoyo anterior y la caída de la espalda hacia la superficie. Puede servir para diseñar encuadres posteriores o transiciones entre poses.  
**Observación de archivo:** El tratamiento es doméstico y neutro; no corresponde a ninguno de los tres escenarios de iluminación del manual.

### DCX-REF-072 · página(s) 60, 90

**Familia:** Estudio de recorte / postura baja  
**Dimensiones de fuente:** 479 × 639 px  
**Descripción:** Recorte más cercano de la misma familia de pose posterior sobre la cama, centrado en la parte baja de la figura y el apoyo.  
**Análisis / uso:** Se mantiene independiente de la 071 porque el encuadre y la lectura de la postura son distintos. El valor está en el detalle compositivo y en la dirección de las líneas.  
**Observación de archivo:** Debe usarse como fragmento de referencia, no como nueva ficha de vestuario completo.

### DCX-REF-073 · página(s) 61, 91

**Familia:** Estudio de pierna / iluminación cálida  
**Dimensiones de fuente:** 479 × 639 px  
**Descripción:** Detalle diagonal de piernas flexionadas y medias junto a la cama, con una temperatura de luz más cálida y baja.  
**Análisis / uso:** Sirve como estudio de accesorio y de la relación entre luz ambiente y textura de la media.  
**Observación de archivo:** La calidez no convierte por sí misma la toma en Blood Cherry; el rojo no domina la imagen como un esquema monocromático.

### DCX-REF-074 · página(s) 62

**Familia:** Estudio de vestuario / conjunto tipo delantal  
**Dimensiones de fuente:** 359 × 639 px  
**Descripción:** Plano frontal parcial de torso y cintura con una prenda negra estructurada, tirantes y un elemento oscuro alrededor del cuello; el entorno parece una cocina.  
**Análisis / uso:** Documenta una línea de vestuario alternativa: piezas negras con correas y una construcción tipo delantal. No coincide con SXW ni con Gloom Grass y conviene mantenerla como estudio de vestuario independiente.  
**Observación de archivo:** Es una posible base para una variante futura, pero todavía no tiene nombre canónico en el manual.

### DCX-REF-075 · página(s) 63

**Familia:** Estudio de vestuario / delantal frontal  
**Dimensiones de fuente:** 359 × 639 px  
**Descripción:** Vista frontal más clara del mismo conjunto negro de correas en el entorno de cocina. La pose vertical permite leer la disposición del panel frontal.  
**Análisis / uso:** Completa la referencia 074 al mostrar el conjunto desde un ángulo más directo. Es útil para documentar cortes, tirantes y cómo se ajusta la prenda al torso.  
**Observación de archivo:** Debe conservarse como una familia de estudio, sin rebautizarla como Gloom Grass.

### DCX-REF-076 · página(s) 64, 94

**Familia:** Estudio de vestuario / perfil  
**Dimensiones de fuente:** 359 × 639 px  
**Descripción:** Vista lateral del atuendo negro tipo delantal, con un brazo cruzado sobre el torso. El encuadre muestra la profundidad de las correas.  
**Análisis / uso:** Añade información del perfil y del volumen lateral que no aparece en las tomas frontales.  
**Observación de archivo:** La coherencia entre 074–076 sugiere una pequeña secuencia de diseño, no una mera repetición de pose.

### DCX-REF-077 · página(s) 65, 95

**Familia:** Estudio de vestuario / ángulo alternativo  
**Dimensiones de fuente:** 359 × 639 px  
**Descripción:** Otro perfil del atuendo negro con tirantes, en cocina; el brazo y el torso adoptan una posición distinta, lo que cambia la lectura de las correas.  
**Análisis / uso:** Aporta una segunda solución de pose para evaluar cómo se comporta la prenda desde el lado.  
**Observación de archivo:** Se diferencia de la 076 por la distribución de brazos y el ángulo corporal.

### DCX-REF-078 · página(s) 66, 96

**Familia:** Estudio de vestuario / espalda  
**Dimensiones de fuente:** 577 × 639 px  
**Descripción:** Vista posterior de la misma familia de prendas con correas que se atan o prolongan por la espalda; un brazo elevado hace visibles los puntos de sujeción.  
**Análisis / uso:** Es una referencia importante para la construcción: expone cómo se organizan los tirantes en la parte posterior.  
**Observación de archivo:** El detalle posterior completa el estudio 074–079 y debe mantenerse enlazado a esa secuencia.

### DCX-REF-079 · página(s) 67, 97

**Familia:** Estudio de vestuario / espalda completa  
**Dimensiones de fuente:** 552 × 639 px  
**Descripción:** Vista posterior más centrada del conjunto negro, con tiras largas que caen por la espalda y el espacio de cocina como contexto.  
**Análisis / uso:** Permite evaluar la simetría y la longitud de los tirantes con una postura más estable.  
**Observación de archivo:** Es complementaria de la 078: la anterior revela los puntos de ajuste; esta deja leer la caída general.

### DCX-REF-080 · página(s) 68, 98

**Familia:** Estudio de vestuario / detalle posterior  
**Dimensiones de fuente:** 359 × 639 px  
**Descripción:** Tercera vista de espalda, con el torso girado hacia la encimera y la distribución de correas visible en diagonal.  
**Análisis / uso:** Aporta variación de movimiento y cómo las tiras se desplazan con el giro del tronco.  
**Observación de archivo:** Con 078–080 se conforma una secuencia útil de referencia del atuendo alternativo.

### DCX-REF-081 · página(s) 68, 98

**Familia:** Estudio de vestuario / espalda inclinada  
**Dimensiones de fuente:** 359 × 639 px  
**Descripción:** Vista posterior centrada de la familia de prendas negras con correas, inclinada hacia una encimera en el entorno de cocina.  
**Análisis / uso:** Aporta una lectura clara de la caída de las tiras por la espalda durante una postura de inclinación.  
**Observación de archivo:** Se enlaza con la secuencia 074–080 de vestuario tipo delantal, sin elevarla a categoría canónica.

### DCX-REF-082 · página(s) 68, 98

**Familia:** Estudio de vestuario / espalda en tres cuartos  
**Dimensiones de fuente:** 359 × 639 px  
**Descripción:** Vista posterior ligeramente girada hacia el costado, con el mismo conjunto de correas y el fondo de cocina.  
**Análisis / uso:** Completa el estudio de espalda mostrando cómo cambia la distribución de tiras al rotar el torso.  
**Observación de archivo:** Es una toma distinta de 080 y 081 por ángulo y pose; conserva un lugar propio en la secuencia.

### DCX-REF-083 · página(s) 69, 99

**Familia:** Estudio de accesorio / pierna en formato apaisado  
**Dimensiones de fuente:** 1366 × 455 px  
**Descripción:** Recorte horizontal de prendas oscuras y detalles multicolor de media o calcetín sobre una pierna.  
**Análisis / uso:** Es un recurso de detalle para accesorios y textura; su formato panorámico no sirve como retrato completo, pero puede acompañar una ficha de vestuario.  
**Observación de archivo:** El recorte preserva un motivo de color histórico que conviene distinguir de la banda azul AMX consolidada.

### DCX-REF-084 · página(s) 69, 99

**Familia:** Estudio de vestuario / malla oscura  
**Dimensiones de fuente:** 520 × 639 px  
**Descripción:** Toma vertical posterior en tres cuartos con prenda inferior de malla negra y un sofá oscuro como fondo.  
**Análisis / uso:** Aporta una referencia de materialidad y de pose lateral/posterior. No debe confundirse con Gloom Grass completo, ya que no aparecen juntos chaqueta biker, malla superior y cadena industrial.  
**Observación de archivo:** La textura de malla es una referencia parcial de material, no una ficha cerrada de la apariencia Gloom Grass.

### DCX-REF-085 · página(s) 70, 100

**Familia:** Estudio de pose / sofá de cuero  
**Dimensiones de fuente:** 524 × 639 px  
**Descripción:** Pose posterior sentada o reclinada sobre un sofá de cuero negro, con prenda inferior de malla oscura con ribete contrastante y calcetines altos con acentos multicolor.  
**Análisis / uso:** Permite estudiar la interacción entre el cuerpo y el asiento, además de la relación entre ribetes de la prenda y accesorios de pierna.  
**Observación de archivo:** El sofá aporta una base escénica reutilizable para composiciones oscuras; sin máscara, sigue siendo estudio y no ficha de DCX canónico.

### DCX-REF-086 · página(s) 71, 101

**Familia:** Estudio de pose / sofá en tres cuartos  
**Dimensiones de fuente:** 519 × 639 px  
**Descripción:** Vista posterior de tres cuartos inclinada sobre el sofá, con prenda de ribete claro y calcetines oscuros con acentos arcoíris sobre un textil estampado.  
**Análisis / uso:** Complementa la 085 con mayor lectura del ángulo lateral y del patrón del entorno.  
**Observación de archivo:** La pose y el recorte son distintos de la imagen anterior, por lo que merece conservarse como variante.

### DCX-REF-087 · página(s) 72, 102

**Familia:** Estudio de pose / luz violeta-azul  
**Dimensiones de fuente:** 519 × 639 px  
**Descripción:** Pose posterior de rodillas bajo iluminación violeta y azul intensa, con un ribete azul brillante que perfila la prenda oscura y calcetines claros.  
**Análisis / uso:** Aporta una referencia de silueta y luz de contorno para futuros ambientes fríos.  
**Observación de archivo:** No es FireIce estricto: predomina el azul/violeta y no se aprecia el contraste bícromo rojo/azul con el mismo peso.

### DCX-REF-088 · página(s) 73, 103

**Familia:** Estudio de pose / recorte violeta-azul  
**Dimensiones de fuente:** 359 × 639 px  
**Descripción:** Encuadre vertical estrecho de la pose posterior en luz azul-violeta; se mantiene el ribete azul de la prenda oscura y el accesorio claro de pierna.  
**Análisis / uso:** Funciona como alternativa de recorte de la familia visual de la 087, con menos fondo y más concentración en la silueta.  
**Observación de archivo:** El encuadre más cerrado justifica una ficha separada, aunque pertenezca a la misma familia de pose e iluminación.

### DCX-REF-089 · página(s) 73, 103

**Familia:** Estudio de pose / plano posterior abierto  
**Dimensiones de fuente:** 653 × 639 px  
**Descripción:** Versión más amplia de la pose posterior bajo luz azul-violeta, con más información del entorno y de la postura.  
**Análisis / uso:** Complementa la 088: deja estudiar la relación entre figura, fondo, luz de contorno y espacio.  
**Observación de archivo:** No es una repetición exacta del recorte estrecho; aporta una lectura espacial distinta.

### DCX-REF-090 · página(s) 74, 104

**Familia:** DCX enmascarado / variante de luz fría  
**Dimensiones de fuente:** 359 × 639 px  
**Descripción:** Pose sentada de tres cuartos con máscara Kitsune blanca, torso descubierto y prenda inferior clara, bajo iluminación azul-violeta.  
**Análisis / uso:** Es la primera imagen nueva del bloque que recupera claramente la máscara Kitsune canónica. El encuadre escultórico y la temperatura fría amplían el repertorio de DCX sin alterar su ADN visual.  
**Observación de archivo:** La escena funciona como variante fría/Adonis; no debe etiquetarse como FireIce pleno porque la división cálida-fría no está equilibrada.

### DCX-REF-091 · página(s) 75, 105

**Familia:** DCX enmascarado / variante Grass Bass  
**Dimensiones de fuente:** 359 × 639 px  
**Descripción:** Selfie de espejo con máscara Kitsune blanca de marcas rojas y borlas, camisa blanca abierta y prenda inferior clara. El cuarto recibe proyecciones láser verdes y algunos acentos rojos.  
**Análisis / uso:** Una de las referencias nuevas más valiosas para el personaje: reúne máscara canónica y silueta cercana a SXW, bajo una variante verde del cuarto.  
**Observación de archivo:** Puede catalogarse como SXW bajo Grass Bass, sin confundir el verde ambiental con Gloom Grass, que exige el vestuario industrial de cuero/malla/cadena.

### DCX-REF-092 · página(s) 76, 106

**Familia:** DCX enmascarado / variante Grass Bass panorámica  
**Dimensiones de fuente:** 359 × 639 px  
**Descripción:** Versión más amplia del autorretrato ante el espejo, con máscara Kitsune, camisa blanca abierta y proyecciones verdes que cubren el marco y el cuarto.  
**Análisis / uso:** Aporta contexto espacial y mobiliario que no se perciben tanto en la 091. Es especialmente útil para entender el escenario como parte de la composición.  
**Observación de archivo:** Se conserva como imagen distinta por su escala y contexto, no como duplicado de la selfie más cerrada.

### DCX-REF-093 · página(s) 77, 107

**Familia:** Estudio de máscara alternativa / retrato  
**Dimensiones de fuente:** 359 × 639 px  
**Descripción:** Figura con máscara blanca sonriente de estilo Guy Fawkes, vestuario oscuro y luz azul-violeta. No es la máscara Kitsune del diseño oficial.  
**Análisis / uso:** Se archiva como referencia de máscara alternativa y atmósfera, no como apariencia canónica de DCX.  
**Observación de archivo:** La fisonomía de la máscara es distinta de la Kitsune fija y debe quedar visualmente segregada.

### DCX-REF-094 · página(s) 78, 108

**Familia:** Estudio de utilería / máscara alternativa  
**Dimensiones de fuente:** 1136 × 639 px  
**Descripción:** Composición horizontal de una máscara blanca sonriente tipo Guy Fawkes sobre una cama o cubierta textil a cuadros, bajo iluminación azul-violeta.  
**Análisis / uso:** Es una referencia de objeto y puesta en escena, no una imagen de DCX con la máscara oficial puesta.  
**Observación de archivo:** Se diferencia de la 093 por convertir la máscara en objeto dentro del escenario, lo que justifica una ficha propia.

### DCX-REF-095 · página(s) 80

**Familia:** Estudio de pose / perfil de torso  
**Dimensiones de fuente:** 324 × 639 px  
**Descripción:** Vista lateral del torso con un brazo elevado, prenda oscura de tirantes y cocina de fondo.  
**Análisis / uso:** Complementa la secuencia de vestuario tipo delantal al mostrar el comportamiento de las correas y el perfil del torso desde otro ángulo.  
**Observación de archivo:** Se integra en la familia 074–080 como estudio lateral adicional, no como prenda oficial.

### DCX-REF-096 · página(s) 85

**Familia:** Estudio de pose / vista posterior en cocina  
**Dimensiones de fuente:** 660 × 639 px  
**Descripción:** Pose de pie posterior en tres cuartos, con prenda oscura y luz de cocina.  
**Análisis / uso:** Amplía el estudio de silueta posterior y de cómo cambia la forma de la prenda cuando la figura se mantiene erguida.  
**Observación de archivo:** Debe leerse como material de referencia de postura y vestuario, sin inferir una nueva identidad de personaje.

### DCX-REF-097 · página(s) 92

**Familia:** Estudio de pose / perfil en cocina  
**Dimensiones de fuente:** 359 × 639 px  
**Descripción:** Vista lateral del torso con un brazo elevado y una prenda oscura de tirantes; se reconoce el entorno de cocina.  
**Análisis / uso:** Complementa la secuencia 074–080 al mostrar el perfil, el volumen del torso y el comportamiento de las correas desde otra dirección.  
**Observación de archivo:** Es material de pose y vestuario alternativo, no prueba de una cuarta apariencia oficial.

### DCX-REF-098 · página(s) 93

**Familia:** Estudio de pose / tres cuartos posterior en cocina  
**Dimensiones de fuente:** 329 × 639 px  
**Descripción:** Pose de pie desde atrás en tres cuartos, con prenda interior oscura y luz cálida de cocina.  
**Análisis / uso:** Amplía el estudio de silueta posterior y de cómo se distribuye la prenda en una postura erguida.  
**Observación de archivo:** No se ve máscara ni accesorios canónicos suficientes; se conserva como estudio de pose.

### DCX-REF-099 · página(s) 108

**Familia:** Estudio de pose / recorte junto al sofá  
**Dimensiones de fuente:** 479 × 639 px  
**Descripción:** Composición posterior y lateral de menor resolución junto a un sofá negro, con prenda oscura.  
**Análisis / uso:** Sirve como referencia secundaria de pose y relación con mobiliario. La resolución y el recorte aconsejan usarla para consulta, no como imagen destacada de alta definición.  
**Observación de archivo:** Es una fuente nativa pequeña (479 × 639 px); no se debe ampliar artificialmente para simular más detalle.

### DCX-REF-100 · página(s) 109

**Familia:** Estudio de pose / tres cuartos posterior  
**Dimensiones de fuente:** 520 × 639 px  
**Descripción:** Vista posterior en tres cuartos con prenda oscura de ribete brillante o contrastante, calcetines multicolor y una mano apoyada cerca de la cadera.  
**Análisis / uso:** Combina gesto de mano, ribete de prenda y accesorio de pierna; es una referencia visual más específica que una pose neutra.  
**Observación de archivo:** El ribete destaca contra la base oscura y puede inspirar una variante de color, aunque no lleva máscara.

### DCX-REF-101 · página(s) 110

**Familia:** Estudio de pose / luz roja-anaranjada  
**Dimensiones de fuente:** 465 × 639 px  
**Descripción:** Pose posterior de rodillas bajo iluminación monocromática rojo-anaranjada, con prenda oscura de ribete azul pálido o claro.  
**Análisis / uso:** Aporta una silueta baja y una referencia de contraste de borde para escenas cálidas intensas.  
**Observación de archivo:** El baño rojo no basta para declararla Blood Cherry: no muestra aún la composición canónica completa ni el destello azul horizontal escaso.

### DCX-REF-102 · página(s) 111

**Familia:** Estudio de pose / frontal sobre fondo azul marino  
**Dimensiones de fuente:** 359 × 639 px  
**Descripción:** Figura sentada de frente con prenda oscura semitransparente y accesorio oscuro alrededor del cuello, recortada sobre un fondo azul marino.  
**Análisis / uso:** Se conserva como estudio independiente de pose frontal, contraste y vestuario. No lleva máscara Kitsune ni la indumentaria identificadora de SXW o Gloom Grass.  
**Observación de archivo:** Es una referencia separada del canon principal; puede orientar una futura dirección artística, pero no define por sí sola un look de DCX.

## Integración propuesta

- Añadir las 43 entradas de `gallery-manifest-additions.json` al arreglo `items` del manifiesto actual; actualizar el título a `The Dark Room of DCX`, el origen a `3.0 DCX.pdf` y el recuento a **99 referencias públicas**.
- Añadir un filtro visual `Estudios` que corresponda al tag `study`. Mantener los filtros existentes para que las tres referencias de máscara canónica sigan siendo descubribles con los filtros de vestuario/iluminación pertinentes.
- Copiar los 43 archivos AVIF de `assets/dcx/DCX_Public_AVIF_Assets.zip/` a la carpeta homónima del repositorio. No descomprimirlos en otra ruta ni cambiar sus nombres.
- No subir las páginas 112–136 ni los tres elementos previamente restringidos. El acceso de 🦁 es un Easter egg de navegación, no una barrera de privacidad.

## Limitaciones de calidad

La codificación AVIF conserva de forma eficiente la información visible en las imágenes de origen. No equivale a disponer de un negativo fotográfico o de un archivo original de cámara. Para esta expansión usé la mayor fuente disponible dentro del PDF y no apliqué ampliación artificial. Si más adelante se reciben los archivos originales, se podrán reemplazar estas referencias preservando IDs y descripciones cuando coincidan exactamente.
