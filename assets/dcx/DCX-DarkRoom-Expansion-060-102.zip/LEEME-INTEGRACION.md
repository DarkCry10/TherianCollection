# Paquete de ampliación — The Dark Room of DCX (REF-060–102)

Este paquete contiene 43 imágenes AVIF reales, 43 fichas descriptivas y un informe de análisis.

## Instalación en el repositorio

1. Descomprime el paquete en la raíz de tu clon local de `DarkCry10/TherianCollection`.
2. Los AVIF ya están dentro de `assets/dcx/DCX_Public_AVIF_Assets.zip/` para coincidir con las rutas de la galería.
3. Desde la raíz del clon local ejecuta `python apply_expansion.py`. El script valida los 43 AVIF, incorpora las fichas, actualiza el manifiesto/README/HTML y añade el filtro `Estudios`. No modifica `hidden-room.js`.
4. Revisa los cambios, crea tu commit y publícalo cuando lo decidas. El script solo modifica archivos locales; no hace push ni merge. No publiques material de las páginas 112–136.

**Estado:** paquete preparado localmente; los binarios todavía no están cargados al repositorio GitHub. No publiques el manifiesto antes de subir las 43 imágenes, para evitar tarjetas con imágenes rotas.
