#!/usr/bin/env python3
"""Apply DCX refs 060-102 to a local TherianCollection clone.

Run from the repository root after extracting this package into that root.
The script edits local files only; it never commits or pushes to GitHub.
"""
from pathlib import Path
import json
import re
import sys

ROOT = Path.cwd()
manifest_path = ROOT / 'assets/dcx/gallery-manifest.json'
index_path = ROOT / 'index.html'
readme_path = ROOT / 'assets/dcx/README.md'
addition_path = ROOT / 'gallery-manifest-additions.json'
image_dir = ROOT / 'assets/dcx/DCX_Public_AVIF_Assets.zip'

for p in (manifest_path, index_path, readme_path, addition_path):
    if not p.is_file():
        sys.exit(f'No se encontró el archivo requerido: {p.relative_to(ROOT)}')

manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
addition = json.loads(addition_path.read_text(encoding='utf-8'))
new_items = addition.get('items', [])
if len(new_items) != 43:
    sys.exit(f'Se esperaban 43 fichas nuevas; se encontraron {len(new_items)}.')

existing = manifest.get('items', [])
existing_ids = {item.get('id') for item in existing}
new_ids = [item.get('id') for item in new_items]
if len(new_ids) != len(set(new_ids)) or existing_ids.intersection(new_ids):
    sys.exit('Hay IDs duplicados o colisiones con el manifiesto existente. No se modificó ningún archivo.')

missing = [item['file'] for item in new_items if not (image_dir / item['file']).is_file()]
if missing:
    sys.exit('Faltan imágenes AVIF; no se modificó ningún archivo: ' + ', '.join(missing[:5]))

html = index_path.read_text(encoding='utf-8')
readme = readme_path.read_text(encoding='utf-8')
if 'data-filter="study"' in html and len(existing) == 99:
    sys.exit('La ampliación parece estar aplicada ya; no se realizaron cambios.')

# Update manifest metadata and append the new, source-deduplicated fichas.
manifest['title'] = 'The Dark Room of DCX'
manifest['source'] = '3.0 DCX.pdf · documento maestro de 136 páginas (referencias previas conservadas; páginas 112–136 excluidas de la galería pública)'
manifest['uniquePublicReferences'] = len(existing) + len(new_items)
manifest['items'] = existing + new_items
manifest['excludedSourcePages'] = list(dict.fromkeys(manifest.get('excludedSourcePages', []) + list(range(112, 137))))
manifest['duplicatePolicy'] = 'Una ficha por imagen única. Las apariciones repetidas se conservan en sourcePages.'
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

# Add the studies filter; current gallery JS already evaluates tags generically.
photo_filter = '<button class="dcx-filter" type="button" data-filter="photo" aria-pressed="false">Fotografía</button>'
study_filter = '\n          <button class="dcx-filter" type="button" data-filter="study" aria-pressed="false">Estudios</button>'
if study_filter.strip() not in html:
    if photo_filter not in html:
        sys.exit('No se localizó el filtro Fotografía en index.html. El manifiesto ya fue actualizado; inserta manualmente el filtro Estudios.')
    html = html.replace(photo_filter, photo_filter + study_filter, 1)

html = html.replace('56 fichas únicas', '99 fichas únicas', 1)
old_notice = 'pero se excluyen de esta galería pública.'
new_notice = 'pero se excluyen de esta galería pública. También se excluyen del archivo público las páginas 112–136 de 3.0 DCX.pdf.'
if old_notice in html and 'páginas 112–136' not in html:
    html = html.replace(old_notice, new_notice, 1)
index_path.write_text(html, encoding='utf-8')

# Bring the archive documentation into line without erasing the provenance of the first 56 refs.
readme = readme.replace('The archive contains 56 unique high-quality AVIF derivatives.', 'The archive contains 99 unique high-quality AVIF references, including 43 additions from 3.0 DCX.pdf.')
readme = readme.replace('- 56 public, unique image references; no duplicate cards.', '- 99 public, unique image references; no duplicate cards.')
readme = readme.replace('- Original PDF: 71 pages; 59 unique source images across the full archive.', '- Previous source set: 71 pages. The 3.0 DCX.pdf update adds 43 unique public references from pages 51–111.')
if 'Páginas 112–136' not in readme:
    readme += '\n- Pages 112–136 of 3.0 DCX.pdf are excluded from the public gallery.\n'
if 'New derivatives:' not in readme:
    readme += '\n- New derivatives: AVIF (AV1, CRF 18, YUV 4:4:4), preserving source pixel dimensions without upscaling.\n'
readme_path.write_text(readme, encoding='utf-8')

print(f'Integración local completada: {len(existing)} referencias anteriores + {len(new_items)} nuevas = {len(manifest["items"])}.')
print('Se añadió el filtro Estudios y se actualizaron el título, el recuento, la procedencia y las exclusiones.')
print('No se creó ningún commit ni se publicó nada en GitHub; revisa los cambios y publícalos cuando estés listo.')
